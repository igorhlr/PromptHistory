package com.promptlog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.promptlog.adapter.PromptAdapter;
import com.promptlog.model.Prompt;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Activity principal da Entrega 3
 * Exibe lista de prompts cadastrados dinamicamente
 * Implementa navegação para cadastro e sobre
 */
public class ListagemActivity extends AppCompatActivity {
    
    // Componentes da UI
    private ListView listViewPrompts;
    private Button btnAdicionar;
    private Button btnSobre;
    private TextView tvListaVazia;
    
    // Dados
    private ArrayList<Prompt> listaPrompts;
    private PromptAdapter adapter;
    
    // Launcher para resultado da Activity de Cadastro
    private ActivityResultLauncher<Intent> cadastroLauncher;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listagem);
        
        // Título da activity
        setTitle("📝 PromptLog - Meus Prompts");
        
        // Inicializar componentes
        inicializarComponentes();
        
        // Configurar launcher para resultado
        configurarLauncher();
        
        // Inicializar lista vazia (não carrega mais de resources)
        listaPrompts = new ArrayList<>();
        
        // Configurar adapter customizado
        adapter = new PromptAdapter(this, listaPrompts);
        listViewPrompts.setAdapter(adapter);
        
        // Configurar listeners
        configurarClickListeners();
        
        // Verificar se lista está vazia
        verificarListaVazia();
    }
    
    /**
     * Inicializa todos os componentes da UI
     */
    private void inicializarComponentes() {
        listViewPrompts = findViewById(R.id.listViewPrompts);
        btnAdicionar = findViewById(R.id.btnAdicionar);
        btnSobre = findViewById(R.id.btnSobre);
        tvListaVazia = findViewById(R.id.tvListaVazia);
        
        // DEBUG - Verificar se os botões foram encontrados
        if (btnAdicionar == null) {
            Toast.makeText(this, "ERRO: Botão Adicionar não encontrado!", 
                Toast.LENGTH_LONG).show();
        } else {
            // Forçar visibilidade
            btnAdicionar.setVisibility(View.VISIBLE);
            Toast.makeText(this, "Botão Adicionar inicializado!", 
                Toast.LENGTH_SHORT).show();
        }
        
        if (btnSobre == null) {
            Toast.makeText(this, "ERRO: Botão Sobre não encontrado!", 
                Toast.LENGTH_LONG).show();
        } else {
            // Forçar visibilidade
            btnSobre.setVisibility(View.VISIBLE);
        }
    }
    
    /**
     * Configura o launcher para receber resultado da Activity de Cadastro
     */
    private void configurarLauncher() {
        cadastroLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    // Verificar se o resultado é OK
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        
                        // Extrair dados do Intent
                        String texto = data.getStringExtra("texto");
                        String categoria = data.getStringExtra("categoria");
                        String prioridade = data.getStringExtra("prioridade");
                        boolean favorito = data.getBooleanExtra("favorito", false);
                        String tags = data.getStringExtra("tags");
                        
                        // Gerar data atual
                        String dataAtual = new SimpleDateFormat("dd/MM/yyyy", 
                            Locale.getDefault()).format(new Date());
                        
                        // Criar novo objeto Prompt
                        int novoId = listaPrompts.size() + 1;
                        Prompt novoPrompt = new Prompt(
                            novoId,
                            texto,
                            categoria,
                            dataAtual,
                            prioridade,
                            favorito,
                            tags
                        );
                        
                        // Adicionar à lista
                        listaPrompts.add(novoPrompt);
                        
                        // Notificar adapter da mudança
                        adapter.notifyDataSetChanged();
                        
                        // Verificar se lista não está mais vazia
                        verificarListaVazia();
                        
                        // Mostrar confirmação
                        Toast.makeText(ListagemActivity.this,
                            "✅ Prompt adicionado com sucesso!",
                            Toast.LENGTH_SHORT).show();
                    }
                }
            }
        );
    }
    
    /**
     * Configura todos os listeners de click
     */
    private void configurarClickListeners() {
        // Botão Adicionar - abre CadastroPromptActivity esperando resultado
        btnAdicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListagemActivity.this, 
                    CadastroPromptActivity.class);
                cadastroLauncher.launch(intent);
            }
        });
        
        // Botão Sobre - abre SobreActivity sem esperar resultado
        btnSobre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListagemActivity.this, 
                    SobreActivity.class);
                startActivity(intent);
            }
        });
        
        // Click em item da lista
        listViewPrompts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Obtém o prompt clicado
                Prompt prompt = listaPrompts.get(position);
                
                // Pega os primeiros 60 caracteres do texto para identificação
                String textoPrompt = prompt.getTexto();
                String textoResumido = textoPrompt.length() > 60 ? 
                    textoPrompt.substring(0, 57) + "..." : textoPrompt;
                
                // Mensagem identificando exatamente qual item foi clicado
                String mensagem = String.format(
                    "📌 VOCÊ CLICOU NO ITEM %d:\n\n" +
                    "\"%s\"\n\n" +
                    "📁 %s | ⚡ %s | 📅 %s",
                    prompt.getId(),
                    textoResumido,
                    prompt.getCategoria(),
                    prompt.getPrioridade(),
                    prompt.getData()
                );
                
                // Mostra Toast com duração longa
                Toast.makeText(ListagemActivity.this, 
                              mensagem, 
                              Toast.LENGTH_LONG).show();
            }
        });
        
        // Long click para ver tags completas
        listViewPrompts.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Prompt prompt = listaPrompts.get(position);
                String tags = prompt.getTags();
                if (tags != null && !tags.isEmpty()) {
                    Toast.makeText(ListagemActivity.this,
                                  "🏷️ Tags do Item #" + prompt.getId() + ":\n" + tags,
                                  Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(ListagemActivity.this,
                                  "🏷️ Item #" + prompt.getId() + " sem tags definidas",
                                  Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
    }
    
    /**
     * Verifica se a lista está vazia e mostra/esconde mensagem apropriada
     */
    private void verificarListaVazia() {
        if (listaPrompts.isEmpty()) {
            tvListaVazia.setVisibility(View.VISIBLE);
            listViewPrompts.setVisibility(View.GONE);
        } else {
            tvListaVazia.setVisibility(View.GONE);
            listViewPrompts.setVisibility(View.VISIBLE);
        }
    }
}
